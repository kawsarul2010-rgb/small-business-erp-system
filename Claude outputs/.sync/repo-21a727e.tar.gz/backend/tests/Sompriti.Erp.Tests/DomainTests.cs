using Sompriti.Erp.Domain.Common;
using Sompriti.Erp.Domain.Entities;
using Sompriti.Erp.Domain.Enums;
using Sompriti.Erp.Domain.Rules;

namespace Sompriti.Erp.Tests;

public class EnumTextTests
{
    [Fact]
    public void Converts_pascal_case_to_upper_snake_and_back()
    {
        Assert.Equal("MOBILE_BANKING", EnumText.ToText(PaymentMethod.MobileBanking));
        Assert.Equal("OPENING_STOCK", EnumText.ToText(AdjustmentReason.OpeningStock));
        Assert.Equal("DRAFT", EnumText.ToText(PostingStatus.Draft));
        Assert.Equal(PaymentMethod.MobileBanking, EnumText.Parse<PaymentMethod>("MOBILE_BANKING"));
        Assert.Equal(MovementType.SalesVoid, EnumText.Parse<MovementType>("sales_void"));
        Assert.Equal(Role.Manager, EnumText.Parse<Role>("Manager"));
    }

    [Fact]
    public void Rejects_unknown_values()
    {
        Assert.False(EnumText.TryParse<Role>("OWNER", out _));
        Assert.False(EnumText.TryParse<Role>("", out _));
    }
}

public class BdMobileTests
{
    [Theory]
    [InlineData("01712345678", "8801712345678")]
    [InlineData("8801712345678", "8801712345678")]
    [InlineData("+8801912345678", "8801912345678")]
    [InlineData("017-1234 5678", "8801712345678")]
    [InlineData(" 01312345678 ", "8801312345678")]
    public void Normalizes_valid_numbers(string input, string expected) => Assert.Equal(expected, BdMobile.Normalize(input));

    [Theory]
    [InlineData("01212345678")]   // operator digit 2 is not valid
    [InlineData("0171234567")]    // too short
    [InlineData("017123456789")]  // too long
    [InlineData("60123456789")]   // Malaysian number
    [InlineData("abc")]
    [InlineData("")]
    public void Rejects_invalid_numbers(string input) => Assert.Null(BdMobile.Normalize(input));

    [Fact]
    public void Displays_local_format() => Assert.Equal("01712345678", BdMobile.ToDisplay("8801712345678"));
}

public class PasswordPolicyTests
{
    [Theory]
    [InlineData("abcdefg1", true)]
    [InlineData("12345678", false)]
    [InlineData("abcdefgh", false)]
    [InlineData("ab1", false)]
    public void Enforces_length_letter_and_digit(string password, bool valid) => Assert.Equal(valid, PasswordPolicy.IsValid(password));
}

public class PostingRulesTests
{
    [Theory]
    [InlineData(PostingStatus.Draft, PostingStatus.Final, true)]
    [InlineData(PostingStatus.Draft, PostingStatus.Void, true)]
    [InlineData(PostingStatus.Final, PostingStatus.Void, true)]
    [InlineData(PostingStatus.Final, PostingStatus.Draft, false)]
    [InlineData(PostingStatus.Void, PostingStatus.Final, false)]
    [InlineData(PostingStatus.Void, PostingStatus.Draft, false)]
    [InlineData(PostingStatus.Final, PostingStatus.Final, false)]
    public void Allows_only_defined_transitions(PostingStatus from, PostingStatus to, bool allowed) =>
        Assert.Equal(allowed, PostingRules.CanTransition(from, to));

    [Fact]
    public void Invalid_transition_throws_conflict()
    {
        var ex = Assert.Throws<DomainException>(() => PostingRules.EnsureTransition(PostingStatus.Void, PostingStatus.Final));
        Assert.Equal(ErrorKind.Conflict, ex.Kind);
        Assert.Equal(ErrorCodes.InvalidStatusTransition, ex.Code);
    }

    [Fact]
    public void Stock_direction_is_positive_for_purchase_and_negative_for_sales()
    {
        Assert.Equal(1, PostingRules.FinalizeSign(TransactionType.Purchase));
        Assert.Equal(-1, PostingRules.FinalizeSign(TransactionType.Sales));
    }
}

public class LineCalculatorTests
{
    private static readonly Product BoxProduct = new()
    {
        Uuid = Guid.NewGuid(), ProductCode = "P-BOX", ProductName = "Box product", Uom = Uom.Box, SecondaryUom = Uom.Pcs, UnitPerBox = 5,
        ProductPurchasePrice = 10m, ProductSalesPrice = 12.5m
    };

    private static readonly Product PcsProduct = new()
    {
        Uuid = Guid.NewGuid(), ProductCode = "P-PCS", ProductName = "Pcs product", Uom = Uom.Pcs,
        ProductPurchasePrice = 3.333m, ProductSalesPrice = 4m
    };

    private static LineValues Calc(LineInput input, Product product, decimal price, out Validator v)
    {
        v = new Validator();
        return LineCalculator.Normalize(input, product, price, "lines[0]", v);
    }

    [Fact]
    public void Srs_example_three_boxes_of_five_equals_fifteen_pcs()
    {
        var r = Calc(new LineInput(null, BoxProduct.Uuid, QuantityType.Box, 3, null, null, null, null, null), BoxProduct, 10m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(15, r.TotalQuantity);
        Assert.Equal(10m, r.PerUnitPrice);
        Assert.Equal(50m, r.PerBoxPrice);
        Assert.Equal(150m, r.TotalPrice);
        Assert.Equal(5, r.UnitPerBoxSnapshot);
    }

    [Fact]
    public void Pcs_line_uses_default_price_and_rounds_half_away_from_zero()
    {
        var r = Calc(new LineInput(null, PcsProduct.Uuid, QuantityType.Pcs, null, 3, null, null, null, null), PcsProduct, 3.335m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(3, r.TotalQuantity);
        Assert.Equal(3.34m, r.PerUnitPrice);
        Assert.Null(r.PerBoxPrice);
        Assert.Equal(10.02m, r.TotalPrice);
    }

    [Fact]
    public void User_entered_values_are_preserved()
    {
        // 3 boxes plus 2 loose pcs, custom box price, custom total
        var r = Calc(new LineInput(null, BoxProduct.Uuid, QuantityType.Box, 3, null, 17, 9.5m, 47.5m, 160m), BoxProduct, 10m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(17, r.TotalQuantity);
        Assert.Equal(9.5m, r.PerUnitPrice);
        Assert.Equal(47.5m, r.PerBoxPrice);
        Assert.Equal(160m, r.TotalPrice);
    }

    [Fact]
    public void Per_box_price_only_derives_per_pcs_price()
    {
        var r = Calc(new LineInput(null, BoxProduct.Uuid, QuantityType.Box, 2, null, null, null, 60m, null), BoxProduct, 10m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(12m, r.PerUnitPrice);
        Assert.Equal(60m, r.PerBoxPrice);
        Assert.Equal(120m, r.TotalPrice);
    }

    [Fact]
    public void Box_quantity_type_requires_pcs_per_box()
    {
        Calc(new LineInput(null, PcsProduct.Uuid, QuantityType.Box, 2, null, null, null, null, null), PcsProduct, 4m, out var v);
        Assert.True(v.HasErrors);
        var ex = Assert.Throws<DomainException>(() => v.ThrowIfInvalid());
        Assert.Contains("lines[0].quantityType", ex.Errors.Keys);
    }

    [Fact]
    public void Quantities_must_be_positive_and_prices_non_negative()
    {
        Calc(new LineInput(null, PcsProduct.Uuid, QuantityType.Pcs, null, 0, null, -1m, null, null), PcsProduct, 4m, out var v);
        var ex = Assert.Throws<DomainException>(() => v.ThrowIfInvalid());
        Assert.Contains("lines[0].unitQuantity", ex.Errors.Keys);
        Assert.Contains("lines[0].totalQuantity", ex.Errors.Keys);
        Assert.Contains("lines[0].perUnitPrice", ex.Errors.Keys);
    }

    [Fact]
    public void Quantity_by_product_sums_active_lines_only()
    {
        var p = Guid.NewGuid();
        var lines = new List<OrderLine>
        {
            new SalesOrderLineItem { ProductUuid = p, TotalQuantity = 5 },
            new SalesOrderLineItem { ProductUuid = p, TotalQuantity = 7 },
            new SalesOrderLineItem { ProductUuid = p, TotalQuantity = 100, Status = RecordStatus.Deleted },
        };
        var result = LineCalculator.QuantityByProduct(lines);
        Assert.Equal(12, result[p]);
    }
}

public class MeasuredUnitTests
{
    private static readonly Product KgProduct = new()
    {
        Uuid = Guid.NewGuid(), ProductCode = "P-KG", ProductName = "Miniket rice", Uom = Uom.Kg,
        ProductPurchasePrice = 78m, ProductSalesPrice = 85m
    };

    private static readonly Product LitreProduct = new()
    {
        Uuid = Guid.NewGuid(), ProductCode = "P-LTR", ProductName = "Loose soybean oil", Uom = Uom.Litre,
        ProductPurchasePrice = 165m, ProductSalesPrice = 175m
    };

    private static readonly Product PcsProduct = new()
    {
        Uuid = Guid.NewGuid(), ProductCode = "P-PCS", ProductName = "Pcs product", Uom = Uom.Pcs,
        ProductPurchasePrice = 3m, ProductSalesPrice = 4m
    };

    private static LineValues Calc(LineInput input, Product product, decimal price, out Validator v)
    {
        v = new Validator();
        return LineCalculator.Normalize(input, product, price, "lines[0]", v);
    }

    [Fact]
    public void Kg_line_keeps_a_fractional_quantity_and_prices_it_per_kg()
    {
        var r = Calc(new LineInput(null, KgProduct.Uuid, QuantityType.Kg, null, 2.5m, null, null, null, null),
            KgProduct, 85m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(2.5m, r.TotalQuantity);
        Assert.Equal(85m, r.PerUnitPrice);
        Assert.Equal(212.5m, r.TotalPrice);
        Assert.Null(r.PerBoxPrice);
    }

    [Fact]
    public void Litre_line_rounds_the_quantity_to_three_decimals()
    {
        var r = Calc(new LineInput(null, LitreProduct.Uuid, QuantityType.Litre, null, 1.23456m, null, 100m, null, null),
            LitreProduct, 175m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(1.235m, r.TotalQuantity);
        Assert.Equal(123.5m, r.TotalPrice);
    }

    [Fact]
    public void A_measured_product_cannot_be_ordered_by_the_piece()
    {
        Calc(new LineInput(null, KgProduct.Uuid, QuantityType.Pcs, null, 3, null, null, null, null),
            KgProduct, 85m, out var v);
        Assert.True(v.HasErrors);
    }

    [Fact]
    public void A_counted_product_rejects_a_fractional_quantity()
    {
        Calc(new LineInput(null, PcsProduct.Uuid, QuantityType.Pcs, null, 2.5m, null, null, null, null),
            PcsProduct, 4m, out var v);
        Assert.True(v.HasErrors);
    }

    [Fact]
    public void Entry_types_follow_the_products_unit()
    {
        static string Types(Product p) => string.Join(",", Units.EntryTypesFor(p));
        var carton = new Product { Uom = Uom.Box, SecondaryUom = Uom.Pcs, UnitPerBox = 12 };
        var sack = new Product { Uom = Uom.Box, SecondaryUom = Uom.Kg, UnitPerBox = 25 };
        var loose = new Product { Uom = Uom.Kg };
        Assert.Equal("Box,Pcs", Types(carton));
        Assert.Equal("Box,Kg", Types(sack));
        Assert.Equal("Kg", Types(loose));
        Assert.Equal(Uom.Kg, Units.BaseUnit(sack));
        Assert.Equal(Uom.Pcs, Units.BaseUnit(carton));
        Assert.True(Units.IsValidFor(carton, QuantityType.Pcs));
        Assert.False(Units.IsValidFor(loose, QuantityType.Pcs));
        Assert.True(Units.AllowsFractions(Uom.Kg));
        Assert.False(Units.AllowsFractions(Uom.Box));
    }

    [Fact]
    public void Every_unit_has_a_matching_quantity_type_and_short_labels()
    {
        foreach (var uom in Enum.GetValues<Uom>())
        {
            var type = Units.AsQuantityType(uom);
            Assert.Equal(uom.ToString(), type.ToString()); // stored as the same text
            Assert.Equal(uom, Units.AsUom(type));
            Assert.Equal(Units.AllowsFractions(uom), Units.AllowsFractions(type));
            Assert.InRange(Units.PrintLabel(uom).Length, 1, 4); // fits the PDF quantity column
        }
        Assert.Equal(Enum.GetValues<Uom>().Length, Enum.GetValues<QuantityType>().Length);
    }

    [Fact]
    public void New_counted_units_take_whole_numbers_and_can_fill_a_box()
    {
        foreach (var uom in new[] { Uom.Dozen, Uom.Packet, Uom.Tin, Uom.Jar, Uom.Drum })
            Assert.False(Units.AllowsFractions(uom));

        var carton = new Product { Uuid = Guid.NewGuid(), ProductCode = "HONEY", Uom = Uom.Box, SecondaryUom = Uom.Jar, UnitPerBox = 12 };
        Assert.Equal("Box,Jar", string.Join(",", Units.EntryTypesFor(carton)));
        Calc(new LineInput(null, carton.Uuid, QuantityType.Box, 2, null, null, null, 3000m, null), carton, 250m, out var ok);
        Assert.False(ok.HasErrors);
        Calc(new LineInput(null, carton.Uuid, QuantityType.Jar, null, 1.5m, null, null, null, null), carton, 250m, out var half);
        Assert.True(half.HasErrors);
    }

    [Fact]
    public void Quantities_print_without_trailing_zeros()
    {
        Assert.Equal("12", Qty.Format(12m));
        Assert.Equal("2.5", Qty.Format(2.5m));
        Assert.Equal("0.75", Qty.Format(0.750m));
        Assert.Equal("2.5 kg", Qty.Format(2.5m, QuantityType.Kg));
        Assert.Equal("12 pcs", Qty.Format(12m, QuantityType.Pcs));
    }

    [Fact]
    public void A_sack_of_25_kg_ordered_by_the_box_becomes_kilos()
    {
        var sack = new Product
        {
            Uuid = Guid.NewGuid(), ProductCode = "P-SACK", ProductName = "Rice sack",
            Uom = Uom.Box, SecondaryUom = Uom.Kg, UnitPerBox = 25,
            ProductPurchasePrice = 78m, ProductSalesPrice = 85m
        };
        var r = Calc(new LineInput(null, sack.Uuid, QuantityType.Box, 2, null, null, null, null, null), sack, 85m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(50m, r.TotalQuantity);          // 2 boxes x 25 kg
        Assert.Equal(85m, r.PerUnitPrice);           // per kg
        Assert.Equal(2125m, r.PerBoxPrice);          // 25 kg x 85
        Assert.Equal(4250m, r.TotalPrice);
        Assert.Equal(25m, r.UnitPerBoxSnapshot);
    }

    [Fact]
    public void The_same_sack_can_be_sold_loose_by_the_kilo()
    {
        var sack = new Product
        {
            Uuid = Guid.NewGuid(), ProductCode = "P-SACK", ProductName = "Rice sack",
            Uom = Uom.Box, SecondaryUom = Uom.Kg, UnitPerBox = 25,
            ProductPurchasePrice = 78m, ProductSalesPrice = 85m
        };
        var r = Calc(new LineInput(null, sack.Uuid, QuantityType.Kg, null, 3.5m, null, null, null, null), sack, 85m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(3.5m, r.TotalQuantity);
        Assert.Equal(297.5m, r.TotalPrice);
        Assert.Null(r.PerBoxPrice);
    }

    [Fact]
    public void A_five_litre_tin_prices_per_litre()
    {
        var tin = new Product
        {
            Uuid = Guid.NewGuid(), ProductCode = "P-TIN", ProductName = "Oil tin",
            Uom = Uom.Box, SecondaryUom = Uom.Litre, UnitPerBox = 5,
            ProductPurchasePrice = 165m, ProductSalesPrice = 175m
        };
        // The user types the box price; the per-litre price follows from the box size.
        var r = Calc(new LineInput(null, tin.Uuid, QuantityType.Box, 3, null, null, null, 900m, null), tin, 175m, out var v);
        Assert.False(v.HasErrors);
        Assert.Equal(15m, r.TotalQuantity);
        Assert.Equal(180m, r.PerUnitPrice);          // 900 / 5
        Assert.Equal(2700m, r.TotalPrice);
    }

    [Fact]
    public void A_box_of_pieces_still_rejects_a_fractional_total()
    {
        var carton = new Product
        {
            Uuid = Guid.NewGuid(), ProductCode = "P-CTN", ProductName = "Soap carton",
            Uom = Uom.Box, SecondaryUom = Uom.Pcs, UnitPerBox = 12,
            ProductPurchasePrice = 48m, ProductSalesPrice = 55m
        };
        Calc(new LineInput(null, carton.Uuid, QuantityType.Pcs, null, 2.5m, null, null, null, null), carton, 55m, out var v);
        Assert.True(v.HasErrors);
    }

    [Fact]
    public void Unit_names_serialize_as_upper_case_text()
    {
        Assert.Equal("KG", EnumText.ToText(Uom.Kg));
        Assert.Equal("LITRE", EnumText.ToText(Uom.Litre));
        Assert.Equal(Uom.Kg, EnumText.Parse<Uom>("KG"));
        Assert.Equal(QuantityType.Litre, EnumText.Parse<QuantityType>("LITRE"));
    }
}

public class SmsTemplateTests
{
    // Md. Ringku's account in the example: 14,19,139 ordered, 5,00,000 paid -> 9,19,139 due.
    private static readonly AccountTotals Account = new(1419139m, 500000m);

    [Fact]
    public void Finalized_sales_message_has_this_order_and_the_total_due_one_per_line()
    {
        var text = SmsTemplates.Order(TransactionType.Sales, "Sompriti Enterprise", "100019", 74590m, 0m, Account);
        Assert.Equal("Sompriti Enterprise\nInvoice #100019 Total: Tk 74,590.00\nPaid: Tk 0.00\nDue: Tk 74,590.00\nTotal Due: Tk 919,139.00\nhttps://tasifmatrix.com.bd", text);
        Assert.Equal(1, SmsParts.Count(text));
    }

    [Fact]
    public void Purchase_message_uses_purchase_wording()
    {
        var text = SmsTemplates.Order(TransactionType.Purchase, "Sompriti Enterprise", "200015", 9800m, 0m, new AccountTotals(9800m, 0m));
        Assert.Contains("\nPurchase #200015 Total: Tk 9,800.00\n", text);
        Assert.Contains("\nTotal Due: Tk 9,800.00\n", text);
    }

    [Fact]
    public void After_a_payment_the_order_shows_what_is_paid_and_still_due_on_it()
    {
        var text = SmsTemplates.Order(TransactionType.Sales, "Sompriti Enterprise", "100023", 4000.5m, 1500m, new AccountTotals(4000.5m, 1500m));
        Assert.Contains("\nPaid: Tk 1,500.00\nDue: Tk 2,500.50\nTotal Due: Tk 2,500.50\n", text);
    }

    [Fact]
    public void A_previous_due_has_no_invoice_number()
    {
        var text = SmsTemplates.Order(TransactionType.Sales, "Sompriti Enterprise", "100020", 1246549m, 500000m, Account, openingDue: true);
        Assert.Contains("\nPrevious Due: Tk 1,246,549.00\nPaid: Tk 500,000.00\nDue: Tk 746,549.00\nTotal Due: Tk 919,139.00\n", text);
        Assert.DoesNotContain("#100020", text);
    }

    [Fact]
    public void Long_company_names_are_cut_to_30_characters()
    {
        var text = SmsTemplates.Order(TransactionType.Sales, "A very long company name that goes on and on", "100001", 50m, 0m, new AccountTotals(50m, 0m));
        Assert.StartsWith("A very long company name that\n", text);
    }

    [Theory]
    [InlineData("Sompriti Enterprise", 12450, 148200, 120000)]
    [InlineData("A company name thirty chars xx", 99999, 999999, 999999)]
    public void Every_message_is_six_lines_from_company_to_website(string company, int amount, int total, int paid)
    {
        foreach (var type in new[] { TransactionType.Sales, TransactionType.Purchase })
        {
            var text = SmsTemplates.Order(type, company, "100042", amount, 0, new AccountTotals(total, paid));
            Assert.StartsWith(company + "\n", text);
            Assert.EndsWith("\n" + SmsTemplates.Website, text);
            Assert.Equal(6, text.Split('\n').Length);
        }
    }
}

public class SmsPartsTests
{
    [Theory]
    [InlineData(1, "")]
    [InlineData(1, "Hello")]
    [InlineData(1, 160)]
    [InlineData(2, 161)]
    [InlineData(2, 306)]
    [InlineData(3, 307)]
    public void Plain_text_is_160_per_part_or_153_when_longer(int expected, object text) =>
        Assert.Equal(expected, SmsParts.Count(text as string ?? new string('a', (int)text)));

    [Fact]
    public void Extended_characters_count_twice()
    {
        Assert.Equal(1, SmsParts.Count(new string('a', 158) + "{"));
        Assert.Equal(2, SmsParts.Count(new string('a', 159) + "{"));
    }

    [Fact]
    public void Bangla_makes_the_message_unicode_70_per_part_or_67_when_longer()
    {
        Assert.Equal(1, SmsParts.Count("\u09a7\u09a8\u09cd\u09af\u09ac\u09be\u09a6"));
        Assert.Equal(1, SmsParts.Count(new string('a', 69) + "\u09a7"));
        Assert.Equal(2, SmsParts.Count(new string('a', 70) + "\u09a7"));
        Assert.Equal(3, SmsParts.Count(new string('a', 134) + "\u09a7"));
    }

    [Fact]
    public void Order_messages_are_one_part()
    {
        var text = SmsTemplates.Order(TransactionType.Sales, "Sompriti Enterprise", "100042", 12450m, 0m, new AccountTotals(148200m, 120000m));
        Assert.Equal(1, SmsParts.Count(text));
    }
}

public class SmsRulesTests
{
    [Theory]
    [InlineData(true, true, true, true)]
    [InlineData(false, true, true, false)]
    [InlineData(true, false, true, false)]
    [InlineData(true, true, false, false)]
    public void Sms_goes_out_only_when_order_party_and_business_all_allow_it(bool order, bool party, bool business, bool expected) =>
        Assert.Equal(expected, SmsRules.ShouldSend(order, party, business));

    [Fact]
    public void Blocked_reason_names_the_switch_that_is_off()
    {
        Assert.Null(SmsRules.BlockedReason(true, true, TransactionType.Sales));
        Assert.Equal("SMS is turned off in the business settings.", SmsRules.BlockedReason(false, false, TransactionType.Sales));
        Assert.Equal("SMS is turned off for this customer.", SmsRules.BlockedReason(true, false, TransactionType.Sales));
        Assert.Equal("SMS is turned off for this supplier.", SmsRules.BlockedReason(true, false, TransactionType.Purchase));
    }
}

public class SubscriptionRulesTests
{
    private static readonly DateTimeOffset Now = new(2026, 10, 4, 12, 0, 0, TimeSpan.Zero);

    [Fact]
    public void Billing_off_or_exempt_is_not_billed_and_never_frozen()
    {
        Assert.Equal(SubscriptionState.NotBilled, SubscriptionRules.Evaluate(false, false, Now.AddDays(-100), false, 7, Now).State);
        var exempt = SubscriptionRules.Evaluate(true, true, Now.AddDays(-100), false, 7, Now);
        Assert.Equal(SubscriptionState.NotBilled, exempt.State);
        Assert.False(exempt.Frozen);
    }

    [Fact]
    public void Trial_then_active_then_grace_then_expired()
    {
        var trial = SubscriptionRules.Evaluate(true, false, Now.AddDays(10), true, 7, Now);
        Assert.Equal(SubscriptionState.Trial, trial.State);
        Assert.Equal(10, trial.DaysLeft);

        Assert.Equal(SubscriptionState.Active, SubscriptionRules.Evaluate(true, false, Now.AddHours(5), false, 7, Now).State);

        var grace = SubscriptionRules.Evaluate(true, false, Now.AddDays(-3), false, 7, Now);
        Assert.Equal(SubscriptionState.GracePeriod, grace.State);
        Assert.Equal(4, grace.DaysLeft);
        Assert.Equal(Now.AddDays(4), grace.GraceEndsAt);
        Assert.False(grace.Frozen);

        var expired = SubscriptionRules.Evaluate(true, false, Now.AddDays(-8), false, 7, Now);
        Assert.Equal(SubscriptionState.Expired, expired.State);
        Assert.True(expired.Frozen);
    }

    [Fact]
    public void No_grace_days_freezes_straight_after_the_end()
    {
        Assert.Equal(SubscriptionState.Expired, SubscriptionRules.Evaluate(true, false, Now.AddMinutes(-1), false, 0, Now).State);
    }

    [Fact]
    public void Paying_early_adds_to_the_time_left_and_paying_late_starts_today()
    {
        var early = SubscriptionRules.Extend(Now.AddDays(5), Now, 1);
        Assert.Equal(Now.AddDays(5), early.Start);
        Assert.Equal(Now.AddDays(5).AddMonths(1), early.End);

        var late = SubscriptionRules.Extend(Now.AddDays(-3), Now, 12);
        Assert.Equal(Now, late.Start);
        Assert.Equal(Now.AddYears(1), late.End);

        Assert.Equal(Now.AddMonths(3), SubscriptionRules.Extend(null, Now, 3).End);
    }
}

public class BusinessClockTests
{
    [Fact]
    public void Today_uses_bangladesh_time()
    {
        // 2026-01-01 20:00 UTC is 2026-01-02 02:00 in Dhaka
        var utc = new DateTimeOffset(2026, 1, 1, 20, 0, 0, TimeSpan.Zero);
        Assert.Equal(new DateOnly(2026, 1, 2), BusinessClock.Today(utc));
        Assert.Equal(new DateTimeOffset(2026, 1, 1, 18, 0, 0, TimeSpan.Zero), BusinessClock.StartOfDayUtc(new DateOnly(2026, 1, 2)));
    }
}

public class SmsCreditTests
{
    private static readonly DateTimeOffset Now = new(2026, 10, 16, 6, 0, 0, TimeSpan.Zero);
    private static readonly Guid A = Guid.Parse("00000000-0000-0000-0000-00000000000a");
    private static readonly Guid B = Guid.Parse("00000000-0000-0000-0000-00000000000b");
    private static readonly Guid C = Guid.Parse("00000000-0000-0000-0000-00000000000c");

    [Fact]
    public void Available_counts_only_what_is_left_in_packs_that_have_not_expired()
    {
        var lots = new[]
        {
            new SmsLot(A, 300, 120, Now.AddMonths(2)),
            new SmsLot(B, 20, 5, Now.AddDays(-1)),    // expired: its 15 are gone
            new SmsLot(C, 100, 100, Now.AddMonths(3)), // used up
        };
        Assert.Equal(180, SmsCredits.Available(lots, Now));
    }

    [Fact]
    public void A_message_uses_the_pack_that_expires_first_and_spills_into_the_next()
    {
        var lots = new[] { new SmsLot(A, 100, 0, Now.AddMonths(3)), new SmsLot(B, 20, 19, Now.AddDays(10)) };
        var plan = SmsCredits.Allocate(lots, 2, Now)!;
        Assert.Equal(new[] { (B, 1), (A, 1) }, plan);
    }

    [Fact]
    public void A_short_balance_takes_nothing()
    {
        var lots = new[] { new SmsLot(A, 10, 9, Now.AddMonths(1)), new SmsLot(B, 50, 0, Now.AddDays(-2)) };
        Assert.Null(SmsCredits.Allocate(lots, 2, Now));
        Assert.Empty(SmsCredits.Allocate(lots, 0, Now)!);
    }

    [Fact]
    public void A_failed_message_gives_its_sms_back_to_the_pack_lasting_longest()
    {
        var lots = new[]
        {
            new SmsLot(A, 100, 1, Now.AddMonths(3)),
            new SmsLot(B, 20, 20, Now.AddDays(10)),
            new SmsLot(C, 50, 50, Now.AddDays(-1)), // expired: never refilled
        };
        Assert.Equal(new[] { (A, 1), (B, 1) }, SmsCredits.Refund(lots, 2, Now));
        Assert.Empty(SmsCredits.Refund([new SmsLot(C, 50, 50, Now.AddDays(-1))], 2, Now));
    }

    [Theory]
    [InlineData(300, 0.55, 165.00)]
    [InlineData(100, 0.35, 35.00)]
    [InlineData(333, 0.333, 110.89)]
    public void Price_is_quantity_times_price_rounded_to_paisa(int quantity, double unit, double expected) =>
        Assert.Equal((decimal)expected, SmsCredits.Price(quantity, (decimal)unit));

    [Fact]
    public void A_pack_lasts_the_set_number_of_months()
    {
        Assert.Equal(new DateTimeOffset(2027, 1, 16, 6, 0, 0, TimeSpan.Zero), SmsCredits.ExpiresAt(Now, 3));
        Assert.Equal(new DateTimeOffset(2027, 2, 28, 0, 0, 0, TimeSpan.Zero), SmsCredits.ExpiresAt(new DateTimeOffset(2026, 11, 30, 0, 0, 0, TimeSpan.Zero), 3));
    }
}

public class CostingTests
{
    [Fact]
    public void A_purchase_blends_into_the_average_and_a_sale_leaves_at_it()
    {
        // 10 bottles at Tk 100 on the shelf, 10 more bought at Tk 120.
        var average = Costing.AverageIn(10, 100, 10, 120);
        Assert.Equal(110m, average);
        // Selling 5 costs 5 x 110; the average does not move.
        Assert.Equal(550m, Costing.Value(5, average));
    }

    [Fact]
    public void The_first_stock_on_an_empty_shelf_sets_the_average()
    {
        Assert.Equal(87.5m, Costing.AverageIn(0, 0, 50, 87.5m));
        Assert.Equal(87.5m, Costing.AverageIn(0, 120, 50, 87.5m));
    }

    [Fact]
    public void Voiding_a_purchase_undoes_it()
    {
        Assert.Equal(100m, Costing.AverageOut(20, 110, 10, 120));
        // Nothing left, or arithmetic below zero: the average is kept.
        Assert.Equal(95m, Costing.AverageOut(10, 95, 10, 95));
        Assert.Equal(10m, Costing.AverageOut(12, 10, 10, 50));
    }

    [Fact]
    public void Measured_units_average_to_four_decimals()
    {
        // (12.5 x 64.40 + 7.25 x 66.10) / 19.75 = 65.02405...
        Assert.Equal(65.0241m, Costing.AverageIn(12.5m, 64.40m, 7.25m, 66.10m));
    }

    [Fact]
    public void Profit_counts_the_cost_of_what_was_sold_not_everything_bought()
    {
        // 100 bottles bought at Tk 150; 40 sold at Tk 180; Tk 1,000 of expenses.
        var average = Costing.AverageIn(0, 0, 100, 150);
        var sales = 40 * 180m;
        var costOfGoodsSold = Costing.Value(40, average);
        Assert.Equal(1_200m, sales - costOfGoodsSold);        // gross profit
        Assert.Equal(200m, sales - costOfGoodsSold - 1_000m); // net profit
    }

    [Fact]
    public void Unit_cost_per_product_is_total_price_over_total_quantity()
    {
        var product = Guid.NewGuid();
        var lines = new OrderLine[]
        {
            new PurchaseOrderLineItem { ProductUuid = product, TotalQuantity = 10, TotalPrice = 1_000 },
            new PurchaseOrderLineItem { ProductUuid = product, TotalQuantity = 30, TotalPrice = 3_600 },
            new PurchaseOrderLineItem { ProductUuid = product, TotalQuantity = 5, TotalPrice = 999, Status = RecordStatus.Deleted },
        };
        Assert.Equal(115m, Costing.UnitCostByProduct(lines)[product]);
    }
}
